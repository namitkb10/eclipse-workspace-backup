package basePackage;

public class BaseTest {

}
