package utilities;

public class PropertiesReader {

}
